package com.digitan.prototype

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

/**
 * DIGITAN_01 starter screen. The original APK's private backend contract
 * is not recoverable from the APK alone; configure API_BASE_URL and the
 * request/response fields to match the actual server before deployment.
 */
class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var username: EditText
    private lateinit var password: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        val title = TextView(this).apply {
            text = "DIGITAN_01"
            textSize = 28f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Prototype • Online account sign-in"
            textSize = 14f
            gravity = Gravity.CENTER
        }
        username = EditText(this).apply {
            hint = "Username or email"
            singleLine = true
        }
        password = EditText(this).apply {
            hint = "Password"
            singleLine = true
            inputType =  textInputTypePassword()
        }
        val login = Button(this).apply {
            text = "Sign in"
            setOnClickListener { signIn() }
        }
        status = TextView(this).apply {
            text = "Set the server URL in app/build.gradle before testing login."
            textSize = 13f
        }
        listOf(title, subtitle, username, password, login, status).forEach { view ->
            root.addView(view, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                if (view is EditText) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 16 })
        }
        setContentView(root)
    }

    private fun textInputTypePassword(): Int =
        android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD

    private fun signIn() {
        val user = username.text.toString().trim()
        val pass = password.text.toString()
        if (user.isEmpty() || pass.isEmpty()) {
            status.text = "Enter your username/email and password."
            return
        }
        if (BuildConfig.API_BASE_URL.contains("your-server.example")) {
            status.text = "Login belum tersambung: ganti API_BASE_URL dan sesuaikan kontrak API server."
            return
        }
        status.text = "Connecting…"
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val endpoint = URL(BuildConfig.API_BASE_URL.trimEnd('/') + "/login")
                connection = (endpoint.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 15000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val body = JSONObject().put("username", user).put("password", pass)
                    .toString().toByteArray(StandardCharsets.UTF_8)
                connection.outputStream.use { it.write(body) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code in 200..299) {
                    val json = JSONObject(response)
                    val token = json.optString("access_token", json.optString("token", ""))
                    if (token.isNotBlank()) {
                        getSharedPreferences("session", MODE_PRIVATE).edit()
                            .putString("access_token", token).apply()
                    }
                    runOnUiThread {
                        status.text = if (token.isNotBlank()) "Signed in. Session token saved." else
                            "Server accepted login, but response has no access_token/token field."
                    }
                } else {
                    runOnUiThread { status.text = "Login failed (HTTP $code). Check account or API contract." }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Connection error: ${e.localizedMessage ?: "unknown error"}" }
            } finally {
                connection?.disconnect()
            }
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
