# DIGITAN_01 — Rekonstruksi Android Studio dari Exam_Browser_V2.2.apk

Folder ini adalah **proyek rekonstruksi awal**, bukan pemulihan sempurna source code asli. APK yang diberikan berisi enam DEX hasil kompilasi. Bytecode dan resource non-audio yang dapat diekstrak disimpan di `recovery/` sebagai bahan referensi.

## Yang tersedia
- Kerangka proyek Android Studio berbasis Kotlin.
- Manifest dan konfigurasi Gradle.
- Layar login contoh dengan HTTPS POST yang masih memerlukan kontrak API asli.
- Folder `recovery/original_dex/` berisi enam DEX asli untuk referensi dekompilasi.
- Folder `recovery/resources/` berisi resource APK yang diekstrak, dengan dua resource audio dihilangkan.
- `recovery/APK_ANALYSIS.md` berisi temuan dan batasan.

## Yang belum dapat dijamin
- Kode Kotlin/Java lengkap hasil dekompilasi belum tersedia.
- Endpoint backend, format login, token, database, dan protokol online asli belum terverifikasi.
- Alur ujian, WebView, hasil ujian, dan integrasi server belum direkonstruksi penuh.
- Proyek belum diverifikasi dapat dibuild menjadi APK produksi.

Jangan anggap kerangka login contoh sebagai integrasi ke akun/server asli. Jangan gunakan untuk ujian sungguhan sebelum backend dan seluruh alur diuji.

## Cara melanjutkan
Gunakan JADX untuk mendekompilasi semua `classes*.dex`, kemudian rekonstruksi kelas aplikasi. Identitas kelas aplikasi yang terdeteksi antara lain `com.smkn1clgn.digital.MainActivity`, `ExamActivity`, `ExamResultActivity`, dan `util.ExamAlarm`. Lihat `recovery/APK_ANALYSIS.md`.
