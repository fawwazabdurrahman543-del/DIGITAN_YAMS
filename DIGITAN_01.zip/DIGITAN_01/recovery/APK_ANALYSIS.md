# DIGITAN_01 — Catatan rekonstruksi dari Exam_Browser_V2.2.apk

## Apa yang berhasil diidentifikasi

- Paket berisi enam DEX: `classes.dex`, `classes2.dex`, `classes3.dex`, `classes4.dex`, `classes5.dex`, `classes6.dex`.
- Identifier kelas aplikasi yang terlihat di DEX mencakup:
  - `com.smkn1clgn.digital.MainActivity`
  - `com.smkn1clgn.digital.ExamActivity`
  - `com.smkn1clgn.digital.ExamResultActivity`
  - `com.smkn1clgn.digital.util.ExamAlarm`
- DEX menunjukkan kelas ExamActivity memiliki `setupWebView` dan referensi `triggerNavigationAlarm`.
- Resource APK mencakup `res/layout/dialog_exit_confirm.xml`, `res/layout/zxing_barcode_scanner.xml`, `res/layout/zxing_capture.xml`, dan resource AndroidX/Material lainnya.
- Resource audio `res/raw/navigation_alarm.wav` dan `res/raw/zxing_beep.ogg` sengaja tidak disalin ke folder resource proyek ini.

## Batasan penting

File `.dex` adalah bytecode Dalvik hasil kompilasi, bukan file sumber Kotlin/Java. Folder `original_dex` menyimpan bytecode asli sebagai bahan referensi/pemulihan lanjutan, bukan kode sumber yang bisa langsung diedit di Android Studio. Tanpa proses dekompilasi DEX khusus, sebagian kode sumber tidak tersedia di lingkungan kerja ini. Bahkan setelah dekompilasi, endpoint backend, konfigurasi server, dan perilaku yang hanya berjalan di server tidak otomatis dapat dipulihkan.

Proyek `app/src` saat ini adalah rekonstruksi awal yang dapat diedit, bukan salinan lengkap dari aplikasi lama. Login contoh masih perlu disesuaikan dengan API server sebenarnya. Jangan gunakan untuk ujian sungguhan sebelum semua alur diuji.

## Langkah rekonstruksi berikutnya

1. Dekompilasi keenam DEX dengan JADX pada komputer ketika tersedia.
2. Cocokkan kelas aplikasi hasil dekompilasi dengan struktur paket `com.smkn1clgn.digital`.
3. Rekonstruksi `MainActivity`, `ExamActivity`, `ExamResultActivity`, serta seluruh helper/model/networking yang ditemukan.
4. Hapus pemanggilan detektor hanya setelah fungsi dan dampaknya dipetakan; pertahankan login, sesi, sinkronisasi, dan pengiriman hasil ujian.
5. Hapus pemanggilan pemutar alarm dan resource audio; pastikan tidak ada referensi `R.raw.navigation_alarm` atau `R.raw.zxing_beep` tersisa.
6. Cocokkan endpoint, skema autentikasi, dan API hasil ujian dengan backend resmi.
7. Build, uji, dan tandatangani APK baru dengan kunci milik pemilik aplikasi.
